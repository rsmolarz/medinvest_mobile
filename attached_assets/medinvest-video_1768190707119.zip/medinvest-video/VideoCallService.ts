// lib/video/VideoCallService.ts
/**
 * Video Calling Integration
 * Using Twilio Video SDK (can be swapped for Daily.co, Agora, etc.)
 */

import {
  connect,
  createLocalTracks,
  Room,
  LocalParticipant,
  RemoteParticipant,
  LocalVideoTrack,
  LocalAudioTrack,
  RemoteVideoTrack,
  RemoteAudioTrack,
} from 'twilio-video';

export interface VideoCallConfig {
  roomName: string;
  token: string;
  audio?: boolean;
  video?: boolean;
}

export interface ParticipantInfo {
  identity: string;
  sid: string;
  isLocal: boolean;
  videoTrack?: LocalVideoTrack | RemoteVideoTrack;
  audioTrack?: LocalAudioTrack | RemoteAudioTrack;
  isVideoEnabled: boolean;
  isAudioEnabled: boolean;
}

export type VideoCallEvent = 
  | 'connected'
  | 'disconnected'
  | 'participantConnected'
  | 'participantDisconnected'
  | 'trackSubscribed'
  | 'trackUnsubscribed'
  | 'error';

type EventCallback = (data?: any) => void;

class VideoCallService {
  private room: Room | null = null;
  private localTracks: (LocalVideoTrack | LocalAudioTrack)[] = [];
  private eventListeners: Map<VideoCallEvent, EventCallback[]> = new Map();
  
  // ===========================================================================
  // CONNECTION
  // ===========================================================================
  
  async connect(config: VideoCallConfig): Promise<Room> {
    try {
      // Create local tracks
      this.localTracks = await createLocalTracks({
        audio: config.audio ?? true,
        video: config.video ?? true,
      });
      
      // Connect to room
      this.room = await connect(config.token, {
        name: config.roomName,
        tracks: this.localTracks,
        dominantSpeaker: true,
        networkQuality: {
          local: 1,
          remote: 1,
        },
      });
      
      this.setupRoomListeners();
      this.emit('connected', { room: this.room });
      
      return this.room;
    } catch (error) {
      this.emit('error', { error });
      throw error;
    }
  }
  
  async disconnect(): Promise<void> {
    if (this.room) {
      this.room.disconnect();
      this.room = null;
    }
    
    // Stop local tracks
    this.localTracks.forEach(track => track.stop());
    this.localTracks = [];
    
    this.emit('disconnected');
  }
  
  // ===========================================================================
  // TRACK CONTROLS
  // ===========================================================================
  
  toggleVideo(): boolean {
    const videoTrack = this.localTracks.find(
      track => track.kind === 'video'
    ) as LocalVideoTrack | undefined;
    
    if (videoTrack) {
      if (videoTrack.isEnabled) {
        videoTrack.disable();
      } else {
        videoTrack.enable();
      }
      return videoTrack.isEnabled;
    }
    return false;
  }
  
  toggleAudio(): boolean {
    const audioTrack = this.localTracks.find(
      track => track.kind === 'audio'
    ) as LocalAudioTrack | undefined;
    
    if (audioTrack) {
      if (audioTrack.isEnabled) {
        audioTrack.disable();
      } else {
        audioTrack.enable();
      }
      return audioTrack.isEnabled;
    }
    return false;
  }
  
  isVideoEnabled(): boolean {
    const videoTrack = this.localTracks.find(track => track.kind === 'video');
    return videoTrack?.isEnabled ?? false;
  }
  
  isAudioEnabled(): boolean {
    const audioTrack = this.localTracks.find(track => track.kind === 'audio');
    return audioTrack?.isEnabled ?? false;
  }
  
  async switchCamera(): Promise<void> {
    const videoTrack = this.localTracks.find(
      track => track.kind === 'video'
    ) as LocalVideoTrack | undefined;
    
    if (videoTrack) {
      const currentFacingMode = videoTrack.mediaStreamTrack.getSettings().facingMode;
      const newFacingMode = currentFacingMode === 'user' ? 'environment' : 'user';
      
      // Stop current track
      videoTrack.stop();
      
      // Create new track with different camera
      const [newVideoTrack] = await createLocalTracks({
        video: { facingMode: newFacingMode },
      }) as [LocalVideoTrack];
      
      // Replace in local tracks array
      const index = this.localTracks.indexOf(videoTrack);
      this.localTracks[index] = newVideoTrack;
      
      // Publish to room
      if (this.room?.localParticipant) {
        await this.room.localParticipant.unpublishTrack(videoTrack);
        await this.room.localParticipant.publishTrack(newVideoTrack);
      }
    }
  }
  
  // ===========================================================================
  // PARTICIPANTS
  // ===========================================================================
  
  getLocalParticipant(): ParticipantInfo | null {
    if (!this.room?.localParticipant) return null;
    
    const participant = this.room.localParticipant;
    const videoTrack = this.localTracks.find(t => t.kind === 'video') as LocalVideoTrack;
    const audioTrack = this.localTracks.find(t => t.kind === 'audio') as LocalAudioTrack;
    
    return {
      identity: participant.identity,
      sid: participant.sid,
      isLocal: true,
      videoTrack,
      audioTrack,
      isVideoEnabled: videoTrack?.isEnabled ?? false,
      isAudioEnabled: audioTrack?.isEnabled ?? false,
    };
  }
  
  getRemoteParticipants(): ParticipantInfo[] {
    if (!this.room) return [];
    
    return Array.from(this.room.participants.values()).map(participant => {
      let videoTrack: RemoteVideoTrack | undefined;
      let audioTrack: RemoteAudioTrack | undefined;
      
      participant.videoTracks.forEach(publication => {
        if (publication.track) {
          videoTrack = publication.track;
        }
      });
      
      participant.audioTracks.forEach(publication => {
        if (publication.track) {
          audioTrack = publication.track;
        }
      });
      
      return {
        identity: participant.identity,
        sid: participant.sid,
        isLocal: false,
        videoTrack,
        audioTrack,
        isVideoEnabled: !!videoTrack?.isEnabled,
        isAudioEnabled: !!audioTrack?.isEnabled,
      };
    });
  }
  
  // ===========================================================================
  // EVENT HANDLING
  // ===========================================================================
  
  on(event: VideoCallEvent, callback: EventCallback): void {
    const listeners = this.eventListeners.get(event) || [];
    listeners.push(callback);
    this.eventListeners.set(event, listeners);
  }
  
  off(event: VideoCallEvent, callback: EventCallback): void {
    const listeners = this.eventListeners.get(event) || [];
    const index = listeners.indexOf(callback);
    if (index > -1) {
      listeners.splice(index, 1);
    }
  }
  
  private emit(event: VideoCallEvent, data?: any): void {
    const listeners = this.eventListeners.get(event) || [];
    listeners.forEach(callback => callback(data));
  }
  
  private setupRoomListeners(): void {
    if (!this.room) return;
    
    this.room.on('participantConnected', (participant: RemoteParticipant) => {
      this.emit('participantConnected', { participant });
      this.setupParticipantListeners(participant);
    });
    
    this.room.on('participantDisconnected', (participant: RemoteParticipant) => {
      this.emit('participantDisconnected', { participant });
    });
    
    this.room.on('disconnected', (room, error) => {
      this.emit('disconnected', { error });
    });
    
    // Set up listeners for existing participants
    this.room.participants.forEach(participant => {
      this.setupParticipantListeners(participant);
    });
  }
  
  private setupParticipantListeners(participant: RemoteParticipant): void {
    participant.on('trackSubscribed', track => {
      this.emit('trackSubscribed', { participant, track });
    });
    
    participant.on('trackUnsubscribed', track => {
      this.emit('trackUnsubscribed', { participant, track });
    });
  }
}

export const videoCallService = new VideoCallService();

// ===========================================================================
// REACT NATIVE COMPONENTS
// ===========================================================================

// components/VideoCall/VideoCallScreen.tsx
import React, { useEffect, useState, useCallback } from 'react';
import { View, StyleSheet, TouchableOpacity, Text, SafeAreaView, StatusBar } from 'react-native';
import { TwilioVideoLocalView, TwilioVideoParticipantView } from 'react-native-twilio-video-webrtc';

interface VideoCallScreenProps {
  roomName: string;
  token: string;
  onEnd: () => void;
}

export function VideoCallScreen({ roomName, token, onEnd }: VideoCallScreenProps) {
  const [isConnected, setIsConnected] = useState(false);
  const [isAudioEnabled, setIsAudioEnabled] = useState(true);
  const [isVideoEnabled, setIsVideoEnabled] = useState(true);
  const [participants, setParticipants] = useState<ParticipantInfo[]>([]);
  const [isFrontCamera, setIsFrontCamera] = useState(true);
  
  useEffect(() => {
    connectToRoom();
    
    return () => {
      videoCallService.disconnect();
    };
  }, []);
  
  const connectToRoom = async () => {
    try {
      await videoCallService.connect({
        roomName,
        token,
        audio: true,
        video: true,
      });
      
      setIsConnected(true);
      
      videoCallService.on('participantConnected', updateParticipants);
      videoCallService.on('participantDisconnected', updateParticipants);
      videoCallService.on('trackSubscribed', updateParticipants);
    } catch (error) {
      console.error('Failed to connect:', error);
    }
  };
  
  const updateParticipants = useCallback(() => {
    setParticipants(videoCallService.getRemoteParticipants());
  }, []);
  
  const handleToggleAudio = () => {
    const enabled = videoCallService.toggleAudio();
    setIsAudioEnabled(enabled);
  };
  
  const handleToggleVideo = () => {
    const enabled = videoCallService.toggleVideo();
    setIsVideoEnabled(enabled);
  };
  
  const handleSwitchCamera = async () => {
    await videoCallService.switchCamera();
    setIsFrontCamera(!isFrontCamera);
  };
  
  const handleEndCall = async () => {
    await videoCallService.disconnect();
    onEnd();
  };
  
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" />
      
      {/* Remote Participants */}
      <View style={styles.remoteContainer}>
        {participants.length > 0 ? (
          participants.map(participant => (
            <TwilioVideoParticipantView
              key={participant.sid}
              style={styles.remoteVideo}
              participantSid={participant.sid}
            />
          ))
        ) : (
          <View style={styles.waitingContainer}>
            <Text style={styles.waitingText}>Waiting for others to join...</Text>
          </View>
        )}
      </View>
      
      {/* Local Video */}
      <View style={styles.localContainer}>
        {isVideoEnabled ? (
          <TwilioVideoLocalView
            style={styles.localVideo}
            enabled={true}
          />
        ) : (
          <View style={[styles.localVideo, styles.videoOff]}>
            <Text style={styles.videoOffText}>Camera Off</Text>
          </View>
        )}
      </View>
      
      {/* Controls */}
      <View style={styles.controls}>
        <TouchableOpacity
          style={[styles.controlButton, !isAudioEnabled && styles.controlButtonOff]}
          onPress={handleToggleAudio}
        >
          <Text style={styles.controlIcon}>{isAudioEnabled ? '🎤' : '🔇'}</Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.controlButton, !isVideoEnabled && styles.controlButtonOff]}
          onPress={handleToggleVideo}
        >
          <Text style={styles.controlIcon}>{isVideoEnabled ? '📹' : '📷'}</Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={styles.controlButton}
          onPress={handleSwitchCamera}
        >
          <Text style={styles.controlIcon}>🔄</Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.controlButton, styles.endCallButton]}
          onPress={handleEndCall}
        >
          <Text style={styles.controlIcon}>📞</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  remoteContainer: {
    flex: 1,
  },
  remoteVideo: {
    flex: 1,
  },
  waitingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  waitingText: {
    color: '#fff',
    fontSize: 16,
  },
  localContainer: {
    position: 'absolute',
    top: 60,
    right: 16,
    width: 100,
    height: 150,
    borderRadius: 12,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: '#fff',
  },
  localVideo: {
    flex: 1,
  },
  videoOff: {
    backgroundColor: '#333',
    justifyContent: 'center',
    alignItems: 'center',
  },
  videoOffText: {
    color: '#fff',
    fontSize: 12,
  },
  controls: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 16,
    paddingVertical: 24,
    paddingHorizontal: 16,
  },
  controlButton: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  controlButtonOff: {
    backgroundColor: 'rgba(255, 0, 0, 0.3)',
  },
  endCallButton: {
    backgroundColor: '#FF3B30',
  },
  controlIcon: {
    fontSize: 24,
  },
});

// ===========================================================================
// API ENDPOINTS FOR VIDEO TOKENS
// ===========================================================================

// Server-side: routes/video.ts
/*
import { Router } from 'express';
import Twilio from 'twilio';

const router = Router();
const twilioClient = Twilio(
  process.env.TWILIO_ACCOUNT_SID,
  process.env.TWILIO_AUTH_TOKEN
);

router.post('/token', authenticate, async (req, res) => {
  const { roomName } = req.body;
  const identity = req.user.id.toString();
  
  const token = new Twilio.jwt.AccessToken(
    process.env.TWILIO_ACCOUNT_SID!,
    process.env.TWILIO_API_KEY!,
    process.env.TWILIO_API_SECRET!,
    { identity }
  );
  
  const videoGrant = new Twilio.jwt.AccessToken.VideoGrant({
    room: roomName,
  });
  
  token.addGrant(videoGrant);
  
  res.json({
    success: true,
    data: {
      token: token.toJwt(),
      identity,
      roomName,
    },
  });
});

export default router;
*/
