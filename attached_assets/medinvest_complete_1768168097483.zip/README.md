# MedInvest Mobile App

A React Native mobile application for investing in medical and healthcare innovation. Built with Expo, TypeScript, and a modern tech stack.

![MedInvest Banner](./assets/banner.png)

## 📱 Features

### For Investors
- **Discover Opportunities** - Browse vetted medical investments across biotech, devices, digital health, and more
- **Portfolio Management** - Track investments, monitor performance, and view transaction history
- **Research & Insights** - Access curated articles, market analysis, and expert commentary
- **Secure Authentication** - Apple Sign-In, Google Sign-In with biometric support

### Technical Features
- 🔄 **Offline Support** - React Query persistence with automatic sync
- 🔔 **Push Notifications** - Investment updates, milestones, and opportunities
- 🔗 **Deep Linking** - Share investments and navigate from external links
- 🎨 **Polished UI** - Smooth animations with Reanimated 3
- 📱 **Cross-Platform** - iOS and Android from single codebase

---

## 🏗️ Architecture

```
medinvest_mobile/
├── client/                    # React Native Expo app
│   ├── src/
│   │   ├── api/              # API client and React Query hooks
│   │   ├── components/       # Reusable UI components
│   │   ├── context/          # React Context providers (Auth)
│   │   ├── hooks/            # Custom React hooks
│   │   ├── lib/              # Utilities, validation schemas
│   │   ├── navigation/       # React Navigation setup
│   │   ├── providers/        # App-level providers
│   │   ├── screens/          # Screen components
│   │   ├── services/         # Push notifications, deep links
│   │   ├── theme/            # Design system tokens
│   │   └── types/            # TypeScript type definitions
│   ├── assets/               # Images, fonts, sounds
│   ├── App.tsx               # App entry point
│   ├── app.config.ts         # Expo configuration
│   └── package.json
│
└── server/                    # Express.js backend
    ├── db/
    │   ├── schema.ts         # Drizzle ORM schema
    │   ├── index.ts          # Database connection
    │   └── seed.ts           # Sample data
    ├── routes/               # API route handlers
    ├── middleware/           # Auth middleware
    └── services/             # Business logic
```

---

## 🚀 Getting Started

### Prerequisites

- Node.js 18+
- npm or yarn
- Expo CLI (`npm install -g expo-cli`)
- EAS CLI (`npm install -g eas-cli`)
- iOS Simulator (Mac) or Android Emulator
- PostgreSQL 14+ (for backend)

### Mobile App Setup

```bash
# Navigate to client directory
cd client

# Install dependencies
npm install

# Copy environment variables
cp .env.example .env

# Start Expo development server
npm start

# Run on iOS Simulator
npm run ios

# Run on Android Emulator
npm run android
```

### Backend Setup

```bash
# Navigate to server directory
cd server

# Install dependencies
npm install

# Copy environment variables
cp .env.example .env

# Edit .env with your database credentials
# DATABASE_URL=postgresql://user:password@localhost:5432/medinvest

# Generate database migrations
npx drizzle-kit generate

# Run migrations
npx drizzle-kit migrate

# Seed sample data
npx tsx db/seed.ts

# Start server
npm run dev
```

### Environment Variables

#### Client (.env)
```env
EXPO_PUBLIC_API_URL=http://localhost:3000/api
EXPO_PUBLIC_GOOGLE_IOS_CLIENT_ID=your-ios-client-id
EXPO_PUBLIC_GOOGLE_ANDROID_CLIENT_ID=your-android-client-id
EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID=your-web-client-id
```

#### Server (.env)
```env
DATABASE_URL=postgresql://user:password@localhost:5432/medinvest
JWT_SECRET=your-super-secret-jwt-key
APPLE_CLIENT_ID=com.yourcompany.medinvest
GOOGLE_WEB_CLIENT_ID=your-google-web-client-id
```

---

## 📂 Project Structure

### Screens

| Screen | Path | Description |
|--------|------|-------------|
| Onboarding | `screens/auth/OnboardingScreen` | First-time user walkthrough |
| Login | `screens/auth/LoginScreen` | Apple/Google sign-in |
| Discover | `screens/main/DiscoverScreen` | Investment opportunities |
| Investment Detail | `screens/main/InvestmentDetailScreen` | Full investment info |
| Invest Modal | `screens/main/InvestModalScreen` | Investment flow |
| Portfolio | `screens/main/PortfolioScreen` | User's investments |
| Transactions | `screens/main/TransactionHistoryScreen` | Transaction history |
| Research | `screens/main/ResearchScreen` | Articles and insights |
| Article Detail | `screens/main/ArticleDetailScreen` | Full article view |
| Bookmarks | `screens/main/BookmarkedArticlesScreen` | Saved articles |
| Profile | `screens/main/ProfileScreen` | User profile |
| Settings | `screens/settings/SettingsScreen` | App settings |
| Edit Profile | `screens/settings/EditProfileScreen` | Edit user info |
| Notifications | `screens/settings/NotificationsSettingsScreen` | Notification prefs |

### Components

| Component | Description |
|-----------|-------------|
| `Button` | Primary, Secondary, Outline, Ghost, Gradient variants |
| `Input` | Text input with label, error, icons, validation |
| `Card` | Container with elevation, gradient, outline variants |
| `Avatar` | Image with fallback initials, group support |
| `Badge` | Status indicators, notification badges |
| `ProgressBar` | Linear and circular progress |
| `EmptyState` | Empty, error, offline states |
| `Skeleton` | Loading placeholders |
| `Toast` | Success, error, warning, info notifications |
| `FilterModal` | Investment filter bottom sheet |
| `ErrorBoundary` | React error catching |

### Hooks

| Hook | Description |
|------|-------------|
| `useForm` | Form state management with Zod validation |
| `useDebounce` | Debounced value updates |
| `useSearch` | Search with debouncing |
| `useInfiniteList` | Infinite scroll helper |
| `useRefresh` | Pull-to-refresh helper |
| `useNetwork` | Network connectivity state |
| `useIsOnline` | Simple online check |
| `useToast` | Toast notifications |

---

## 🎨 Design System

### Colors

```typescript
// Primary - Medical Blue
primary: {
  main: '#0066CC',
  dark: '#004C99',
  light: '#3399FF',
}

// Secondary - Investment Green  
secondary: {
  main: '#00A86B',
  dark: '#008F5B',
  light: '#00CC83',
}

// Semantic
success: '#00A86B'
warning: '#F59E0B'
error: '#DC2626'
```

### Typography

- **Large Title**: 28px, Bold
- **Title**: 22px, Bold
- **Heading**: 18px, SemiBold
- **Body**: 16px, Regular
- **Caption**: 12px, Regular

### Spacing

```typescript
xs: 4    // Tight
sm: 8    // Small gaps
md: 16   // Default
lg: 24   // Sections
xl: 32   // Large sections
```

---

## 🔌 API Reference

See [API.md](./API.md) for complete endpoint documentation.

### Quick Reference

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/social` | Social sign-in |
| GET | `/api/auth/me` | Get current user |
| GET | `/api/investments` | List investments |
| GET | `/api/investments/:id` | Investment detail |
| GET | `/api/portfolio/summary` | Portfolio totals |
| POST | `/api/portfolio/invest` | Create investment |
| GET | `/api/articles` | List articles |
| POST | `/api/articles/:id/bookmark` | Toggle bookmark |

---

## 📦 Building for Production

### Development Build

```bash
# iOS Simulator
eas build --profile development --platform ios

# Android APK
eas build --profile development --platform android
```

### Preview Build (Internal Testing)

```bash
eas build --profile preview --platform all
```

### Production Build

```bash
# Build for app stores
eas build --profile production --platform all

# Submit to App Store
eas submit --platform ios

# Submit to Google Play
eas submit --platform android
```

---

## 🧪 Testing

```bash
# Run unit tests
npm test

# Run with coverage
npm run test:coverage

# Watch mode
npm run test:watch

# Type checking
npm run typecheck

# Linting
npm run lint
```

---

## 📱 Screenshots

<table>
  <tr>
    <td><img src="./screenshots/onboarding.png" width="200"/></td>
    <td><img src="./screenshots/discover.png" width="200"/></td>
    <td><img src="./screenshots/investment.png" width="200"/></td>
    <td><img src="./screenshots/portfolio.png" width="200"/></td>
  </tr>
  <tr>
    <td align="center">Onboarding</td>
    <td align="center">Discover</td>
    <td align="center">Investment</td>
    <td align="center">Portfolio</td>
  </tr>
</table>

---

## 🛠️ Tech Stack

### Mobile
- **Framework**: React Native + Expo SDK 51
- **Language**: TypeScript
- **Navigation**: React Navigation 6
- **State**: React Query 5 + Context
- **Animations**: Reanimated 3
- **Forms**: Zod validation + custom hooks
- **UI**: Custom component library

### Backend
- **Runtime**: Node.js + Express
- **Database**: PostgreSQL + Drizzle ORM
- **Auth**: JWT + Social OAuth
- **API**: RESTful JSON

---

## 📄 License

MIT License - see [LICENSE](./LICENSE) for details.

---

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing`)
5. Open a Pull Request

---

## 📞 Support

- Email: support@medinvest.app
- Documentation: https://docs.medinvest.app
- Issues: GitHub Issues
