import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { StyleSheet } from 'react-native';

// Providers
import { QueryProvider } from '@/providers/QueryProvider';
import { NetworkProvider } from '@/providers/NetworkProvider';
import { ToastProvider } from '@/components/Toast';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import { AuthProvider } from '@/context/AuthContext';

// Navigation
import RootNavigator from '@/navigation/RootNavigator';

// Theme
import { colors } from '@/theme';

export default function App() {
  return (
    <GestureHandlerRootView style={styles.container}>
      <ErrorBoundary>
        <SafeAreaProvider>
          <QueryProvider enablePersistence>
            <NetworkProvider>
              <AuthProvider>
                <ToastProvider>
                  <StatusBar style="dark" backgroundColor={colors.background.primary} />
                  <RootNavigator />
                </ToastProvider>
              </AuthProvider>
            </NetworkProvider>
          </QueryProvider>
        </SafeAreaProvider>
      </ErrorBoundary>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});
