import { ExpoConfig, ConfigContext } from 'expo/config';

const IS_DEV = process.env.APP_VARIANT === 'development';
const IS_PREVIEW = process.env.APP_VARIANT === 'preview';

const getUniqueIdentifier = () => {
  if (IS_DEV) return 'com.medinvest.app.dev';
  if (IS_PREVIEW) return 'com.medinvest.app.preview';
  return 'com.medinvest.app';
};

const getAppName = () => {
  if (IS_DEV) return 'MedInvest (Dev)';
  if (IS_PREVIEW) return 'MedInvest (Preview)';
  return 'MedInvest';
};

export default ({ config }: ConfigContext): ExpoConfig => ({
  ...config,
  name: getAppName(),
  slug: 'medinvest',
  version: '1.0.0',
  orientation: 'portrait',
  icon: './assets/icon.png',
  userInterfaceStyle: 'light',
  scheme: 'medinvest',

  // Splash screen
  splash: {
    image: './assets/splash.png',
    resizeMode: 'contain',
    backgroundColor: '#0066CC',
  },

  // Asset bundling
  assetBundlePatterns: ['**/*'],

  // iOS configuration
  ios: {
    supportsTablet: true,
    bundleIdentifier: getUniqueIdentifier(),
    buildNumber: '1',
    infoPlist: {
      NSCameraUsageDescription: 'MedInvest needs access to your camera to upload profile photos.',
      NSPhotoLibraryUsageDescription: 'MedInvest needs access to your photos to upload profile photos.',
      NSFaceIDUsageDescription: 'MedInvest uses Face ID for secure authentication.',
      UIBackgroundModes: ['remote-notification'],
    },
    config: {
      googleSignIn: {
        reservedClientId: process.env.EXPO_PUBLIC_GOOGLE_IOS_CLIENT_ID,
      },
    },
    associatedDomains: [
      'applinks:medinvest.app',
      'applinks:www.medinvest.app',
    ],
    entitlements: {
      'com.apple.developer.applesignin': ['Default'],
    },
  },

  // Android configuration
  android: {
    adaptiveIcon: {
      foregroundImage: './assets/adaptive-icon.png',
      backgroundColor: '#0066CC',
    },
    package: getUniqueIdentifier(),
    versionCode: 1,
    permissions: [
      'android.permission.CAMERA',
      'android.permission.READ_EXTERNAL_STORAGE',
      'android.permission.WRITE_EXTERNAL_STORAGE',
      'android.permission.RECEIVE_BOOT_COMPLETED',
      'android.permission.VIBRATE',
    ],
    googleServicesFile: IS_DEV
      ? './google-services-dev.json'
      : './google-services.json',
    intentFilters: [
      {
        action: 'VIEW',
        autoVerify: true,
        data: [
          {
            scheme: 'https',
            host: 'medinvest.app',
            pathPrefix: '/',
          },
          {
            scheme: 'https',
            host: 'www.medinvest.app',
            pathPrefix: '/',
          },
        ],
        category: ['BROWSABLE', 'DEFAULT'],
      },
    ],
  },

  // Web configuration (for development)
  web: {
    favicon: './assets/favicon.png',
    bundler: 'metro',
  },

  // Plugins
  plugins: [
    'expo-router',
    'expo-font',
    'expo-secure-store',
    [
      'expo-image-picker',
      {
        photosPermission: 'Allow MedInvest to access your photos for profile pictures.',
        cameraPermission: 'Allow MedInvest to access your camera for profile pictures.',
      },
    ],
    [
      'expo-notifications',
      {
        icon: './assets/notification-icon.png',
        color: '#0066CC',
        sounds: ['./assets/sounds/notification.wav'],
      },
    ],
    [
      '@react-native-google-signin/google-signin',
      {
        iosUrlScheme: process.env.EXPO_PUBLIC_GOOGLE_IOS_CLIENT_ID,
      },
    ],
    'expo-apple-authentication',
    [
      'expo-build-properties',
      {
        android: {
          compileSdkVersion: 34,
          targetSdkVersion: 34,
          buildToolsVersion: '34.0.0',
          kotlinVersion: '1.9.0',
        },
        ios: {
          deploymentTarget: '15.0',
        },
      },
    ],
  ],

  // Expo updates (OTA)
  updates: {
    enabled: true,
    fallbackToCacheTimeout: 0,
    url: 'https://u.expo.dev/YOUR_PROJECT_ID',
  },

  // Runtime version for updates
  runtimeVersion: {
    policy: 'sdkVersion',
  },

  // Extra configuration
  extra: {
    eas: {
      projectId: 'YOUR_EAS_PROJECT_ID',
    },
    apiUrl: process.env.EXPO_PUBLIC_API_URL || 'https://api.medinvest.app',
  },

  // Owner
  owner: 'medinvest',

  // Experiments
  experiments: {
    typedRoutes: true,
  },
});
