import React, { useEffect, useState } from 'react';
import { ActivityIndicator, View, StyleSheet } from 'react-native';
import { NavigationContainer, type LinkingOptions } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import { useAuth } from '@/context/AuthContext';
import { colors } from '@/theme';
import { useDeepLinks, linkingConfig } from '@/services/deepLinks';
import { usePushNotifications } from '@/services/notifications';
import { isOnboardingComplete } from '@/screens/auth/OnboardingScreen';

// Navigators
import MainTabNavigator from './MainTabNavigator';
import AuthNavigator from './AuthNavigator';

// Screens
import OnboardingScreen from '@/screens/auth/OnboardingScreen';
import InvestmentDetailScreen from '@/screens/main/InvestmentDetailScreen';
import InvestModalScreen from '@/screens/main/InvestModalScreen';
import ArticleDetailScreen from '@/screens/main/ArticleDetailScreen';
import TransactionHistoryScreen from '@/screens/main/TransactionHistoryScreen';
import BookmarkedArticlesScreen from '@/screens/main/BookmarkedArticlesScreen';
import SettingsScreen from '@/screens/settings/SettingsScreen';
import EditProfileScreen from '@/screens/settings/EditProfileScreen';
import NotificationsSettingsScreen from '@/screens/settings/NotificationsSettingsScreen';
import DocumentsScreen from '@/screens/settings/DocumentsScreen';
import PaymentMethodsScreen from '@/screens/settings/PaymentMethodsScreen';
import SupportScreen from '@/screens/settings/SupportScreen';
import LegalScreen from '@/screens/settings/LegalScreen';

import type { RootStackParamList } from './types';

const RootStack = createNativeStackNavigator<RootStackParamList>();

// Navigation content component (uses navigation hooks)
function NavigationContent() {
  // Initialize deep links and push notifications
  useDeepLinks();
  usePushNotifications();

  const { isAuthenticated, isLoading: authLoading } = useAuth();
  const [showOnboarding, setShowOnboarding] = useState<boolean | null>(null);

  // Check onboarding status
  useEffect(() => {
    async function checkOnboarding() {
      const completed = await isOnboardingComplete();
      setShowOnboarding(!completed);
    }
    checkOnboarding();
  }, []);

  // Show loading while checking auth and onboarding
  if (authLoading || showOnboarding === null) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary.main} />
      </View>
    );
  }

  return (
    <RootStack.Navigator
      screenOptions={{
        headerShown: false,
        animation: 'slide_from_right',
      }}
    >
      {showOnboarding && !isAuthenticated ? (
        // Onboarding flow
        <RootStack.Screen 
          name="Onboarding" 
          component={OnboardingScreen}
          options={{ animation: 'fade' }}
        />
      ) : !isAuthenticated ? (
        // Auth flow
        <RootStack.Screen 
          name="Auth" 
          component={AuthNavigator}
          options={{ animation: 'fade' }}
        />
      ) : (
        // Main app
        <>
          <RootStack.Screen 
            name="Main" 
            component={MainTabNavigator}
            options={{ animation: 'fade' }}
          />
          
          {/* Investment Screens */}
          <RootStack.Screen
            name="InvestmentDetail"
            component={InvestmentDetailScreen}
            options={{ animation: 'slide_from_right' }}
          />
          <RootStack.Screen
            name="InvestModal"
            component={InvestModalScreen}
            options={{
              presentation: 'modal',
              animation: 'slide_from_bottom',
            }}
          />

          {/* Article Screens */}
          <RootStack.Screen
            name="ArticleDetail"
            component={ArticleDetailScreen}
            options={{ animation: 'slide_from_right' }}
          />
          <RootStack.Screen
            name="BookmarkedArticles"
            component={BookmarkedArticlesScreen}
            options={{ animation: 'slide_from_right' }}
          />

          {/* Portfolio Screens */}
          <RootStack.Screen
            name="TransactionHistory"
            component={TransactionHistoryScreen}
            options={{ animation: 'slide_from_right' }}
          />

          {/* Settings Screens */}
          <RootStack.Screen
            name="Settings"
            component={SettingsScreen}
            options={{ animation: 'slide_from_right' }}
          />
          <RootStack.Screen
            name="EditProfile"
            component={EditProfileScreen}
            options={{ 
              presentation: 'modal',
              animation: 'slide_from_bottom',
            }}
          />
          <RootStack.Screen
            name="NotificationsSettings"
            component={NotificationsSettingsScreen}
            options={{ animation: 'slide_from_right' }}
          />
          <RootStack.Screen
            name="Documents"
            component={DocumentsScreen}
            options={{ animation: 'slide_from_right' }}
          />
          <RootStack.Screen
            name="PaymentMethods"
            component={PaymentMethodsScreen}
            options={{ animation: 'slide_from_right' }}
          />
          <RootStack.Screen
            name="Support"
            component={SupportScreen}
            options={{ animation: 'slide_from_right' }}
          />
          <RootStack.Screen
            name="Legal"
            component={LegalScreen}
            options={{ animation: 'slide_from_right' }}
          />
        </>
      )}
    </RootStack.Navigator>
  );
}

// Main navigator with NavigationContainer
export default function RootNavigator() {
  return (
    <NavigationContainer linking={linkingConfig as LinkingOptions<RootStackParamList>}>
      <NavigationContent />
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.background.primary,
  },
});
