import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  useMemo,
  type ReactNode,
} from 'react';
import * as AppleAuthentication from 'expo-apple-authentication';
import * as Google from 'expo-auth-session/providers/google';
import * as WebBrowser from 'expo-web-browser';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Ensure web browser redirect is handled
WebBrowser.maybeCompleteAuthSession();

// Storage keys
const AUTH_TOKEN_KEY = '@medinvest/auth_token';
const USER_DATA_KEY = '@medinvest/user_data';

/**
 * User interface
 */
export interface User {
  id: string;
  email: string;
  firstName?: string;
  lastName?: string;
  fullName?: string;
  avatarUrl?: string;
  provider: 'apple' | 'google';
  isVerified: boolean;
  createdAt: string;
}

/**
 * Authentication state
 */
export interface AuthState {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  error: string | null;
}

/**
 * Authentication context interface
 */
export interface AuthContextType extends AuthState {
  // Actions
  signInWithApple: () => Promise<void>;
  signInWithGoogle: () => Promise<void>;
  signOut: () => Promise<void>;
  clearError: () => void;
  refreshUser: () => Promise<void>;
  
  // Apple availability
  isAppleAuthAvailable: boolean;
}

// Create context
const AuthContext = createContext<AuthContextType | undefined>(undefined);

/**
 * Authentication Provider Props
 */
interface AuthProviderProps {
  children: ReactNode;
}

/**
 * Authentication Provider Component
 */
export function AuthProvider({ children }: AuthProviderProps) {
  // State
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isAppleAuthAvailable, setIsAppleAuthAvailable] = useState(false);

  // Google Auth configuration
  // Note: Replace these with your actual client IDs
  const [googleRequest, googleResponse, googlePromptAsync] = Google.useAuthRequest({
    // These should be environment variables in production
    expoClientId: process.env.EXPO_PUBLIC_GOOGLE_EXPO_CLIENT_ID,
    iosClientId: process.env.EXPO_PUBLIC_GOOGLE_IOS_CLIENT_ID,
    androidClientId: process.env.EXPO_PUBLIC_GOOGLE_ANDROID_CLIENT_ID,
    webClientId: process.env.EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID,
  });

  /**
   * Check Apple Authentication availability
   */
  useEffect(() => {
    const checkAppleAuth = async () => {
      const available = await AppleAuthentication.isAvailableAsync();
      setIsAppleAuthAvailable(available);
    };
    checkAppleAuth();
  }, []);

  /**
   * Load stored authentication on mount
   */
  useEffect(() => {
    const loadStoredAuth = async () => {
      try {
        const [storedToken, storedUser] = await Promise.all([
          AsyncStorage.getItem(AUTH_TOKEN_KEY),
          AsyncStorage.getItem(USER_DATA_KEY),
        ]);

        if (storedToken && storedUser) {
          setToken(storedToken);
          setUser(JSON.parse(storedUser));
        }
      } catch (err) {
        console.error('Failed to load stored auth:', err);
      } finally {
        setIsLoading(false);
      }
    };

    loadStoredAuth();
  }, []);

  /**
   * Handle Google Sign-In response
   */
  useEffect(() => {
    const handleGoogleResponse = async () => {
      if (googleResponse?.type === 'success') {
        const { authentication } = googleResponse;
        
        if (authentication?.accessToken) {
          try {
            setIsLoading(true);
            setError(null);

            // Fetch user info from Google
            const userInfoResponse = await fetch(
              'https://www.googleapis.com/userinfo/v2/me',
              {
                headers: { Authorization: `Bearer ${authentication.accessToken}` },
              }
            );

            if (!userInfoResponse.ok) {
              throw new Error('Failed to fetch Google user info');
            }

            const googleUser = await userInfoResponse.json();

            // Send to backend for authentication
            const authResponse = await authenticateWithBackend({
              provider: 'google',
              token: authentication.accessToken,
              email: googleUser.email,
              firstName: googleUser.given_name,
              lastName: googleUser.family_name,
              avatarUrl: googleUser.picture,
            });

            await saveAuthData(authResponse.token, authResponse.user);
          } catch (err) {
            const message = err instanceof Error ? err.message : 'Google sign-in failed';
            setError(message);
            console.error('Google sign-in error:', err);
          } finally {
            setIsLoading(false);
          }
        }
      } else if (googleResponse?.type === 'error') {
        setError(googleResponse.error?.message || 'Google sign-in was cancelled');
      }
    };

    handleGoogleResponse();
  }, [googleResponse]);

  /**
   * Authenticate with backend API
   */
  const authenticateWithBackend = async (data: {
    provider: 'apple' | 'google';
    token: string;
    email?: string;
    firstName?: string;
    lastName?: string;
    avatarUrl?: string;
    identityToken?: string;
    authorizationCode?: string;
  }): Promise<{ token: string; user: User }> => {
    // TODO: Replace with actual API endpoint
    const response = await fetch('/api/auth/social', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.message || 'Authentication failed');
    }

    return response.json();
  };

  /**
   * Save authentication data to storage
   */
  const saveAuthData = async (authToken: string, userData: User) => {
    await Promise.all([
      AsyncStorage.setItem(AUTH_TOKEN_KEY, authToken),
      AsyncStorage.setItem(USER_DATA_KEY, JSON.stringify(userData)),
    ]);

    setToken(authToken);
    setUser(userData);
  };

  /**
   * Clear authentication data from storage
   */
  const clearAuthData = async () => {
    await Promise.all([
      AsyncStorage.removeItem(AUTH_TOKEN_KEY),
      AsyncStorage.removeItem(USER_DATA_KEY),
    ]);

    setToken(null);
    setUser(null);
  };

  /**
   * Sign in with Apple
   */
  const signInWithApple = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);

      const credential = await AppleAuthentication.signInAsync({
        requestedScopes: [
          AppleAuthentication.AppleAuthenticationScope.FULL_NAME,
          AppleAuthentication.AppleAuthenticationScope.EMAIL,
        ],
      });

      // Extract user data from credential
      const { identityToken, authorizationCode, email, fullName } = credential;

      if (!identityToken) {
        throw new Error('No identity token received from Apple');
      }

      // Send to backend for authentication
      const authResponse = await authenticateWithBackend({
        provider: 'apple',
        token: identityToken,
        identityToken,
        authorizationCode: authorizationCode || undefined,
        email: email || undefined,
        firstName: fullName?.givenName || undefined,
        lastName: fullName?.familyName || undefined,
      });

      await saveAuthData(authResponse.token, authResponse.user);
    } catch (err: any) {
      if (err.code === 'ERR_REQUEST_CANCELED') {
        // User cancelled, don't show error
        return;
      }
      
      const message = err instanceof Error ? err.message : 'Apple sign-in failed';
      setError(message);
      console.error('Apple sign-in error:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  /**
   * Sign in with Google
   */
  const signInWithGoogle = useCallback(async () => {
    try {
      setError(null);
      
      if (!googleRequest) {
        throw new Error('Google sign-in is not configured');
      }

      await googlePromptAsync();
      // Response is handled in useEffect
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Google sign-in failed';
      setError(message);
      console.error('Google sign-in error:', err);
    }
  }, [googleRequest, googlePromptAsync]);

  /**
   * Sign out
   */
  const signOut = useCallback(async () => {
    try {
      setIsLoading(true);

      // Notify backend
      if (token) {
        await fetch('/api/auth/logout', {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }).catch(() => {
          // Ignore logout API errors
        });
      }

      await clearAuthData();
    } catch (err) {
      console.error('Sign out error:', err);
    } finally {
      setIsLoading(false);
    }
  }, [token]);

  /**
   * Clear error
   */
  const clearError = useCallback(() => {
    setError(null);
  }, []);

  /**
   * Refresh user data
   */
  const refreshUser = useCallback(async () => {
    if (!token) return;

    try {
      const response = await fetch('/api/auth/me', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        if (response.status === 401) {
          // Token expired, sign out
          await clearAuthData();
        }
        return;
      }

      const userData = await response.json();
      setUser(userData);
      await AsyncStorage.setItem(USER_DATA_KEY, JSON.stringify(userData));
    } catch (err) {
      console.error('Failed to refresh user:', err);
    }
  }, [token]);

  /**
   * Computed authentication state
   */
  const isAuthenticated = useMemo(() => {
    return !!user && !!token;
  }, [user, token]);

  /**
   * Context value
   */
  const value = useMemo<AuthContextType>(
    () => ({
      user,
      token,
      isLoading,
      isAuthenticated,
      error,
      signInWithApple,
      signInWithGoogle,
      signOut,
      clearError,
      refreshUser,
      isAppleAuthAvailable,
    }),
    [
      user,
      token,
      isLoading,
      isAuthenticated,
      error,
      signInWithApple,
      signInWithGoogle,
      signOut,
      clearError,
      refreshUser,
      isAppleAuthAvailable,
    ]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

/**
 * Hook to use authentication context
 */
export function useAuth(): AuthContextType {
  const context = useContext(AuthContext);

  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }

  return context;
}

export default AuthContext;
