# MedInvest API Reference

Base URL: `https://api.medinvest.app/api` (Production)

## Authentication

All authenticated endpoints require a Bearer token in the Authorization header:

```
Authorization: Bearer <jwt_token>
```

---

## Auth Endpoints

### POST /auth/social
Social sign-in with Apple or Google.

**Request Body:**
```json
{
  "provider": "apple" | "google",
  "token": "access_token_or_id_token",
  "identityToken": "apple_identity_token",  // Apple only
  "email": "user@example.com",              // Optional fallback
  "firstName": "John",                       // Optional
  "lastName": "Doe",                         // Optional
  "avatarUrl": "https://..."                 // Optional
}
```

**Response:** `200 OK`
```json
{
  "token": "jwt_token",
  "user": {
    "id": "uuid",
    "email": "user@example.com",
    "firstName": "John",
    "lastName": "Doe",
    "fullName": "John Doe",
    "avatarUrl": "https://...",
    "provider": "google",
    "isVerified": true,
    "isAccredited": false,
    "createdAt": "2025-01-01T00:00:00Z"
  }
}
```

---

### GET /auth/me
Get current authenticated user.

**Response:** `200 OK`
```json
{
  "id": "uuid",
  "email": "user@example.com",
  "firstName": "John",
  "lastName": "Doe",
  "fullName": "John Doe",
  "phone": "+1234567890",
  "avatarUrl": "https://...",
  "provider": "google",
  "isVerified": true,
  "isAccredited": false,
  "createdAt": "2025-01-01T00:00:00Z",
  "updatedAt": "2025-01-01T00:00:00Z"
}
```

---

### PATCH /auth/me
Update current user profile.

**Request Body:**
```json
{
  "firstName": "John",
  "lastName": "Doe",
  "phone": "+1234567890"
}
```

**Response:** `200 OK` - Updated user object

---

### POST /auth/logout
Logout current session.

**Response:** `200 OK`
```json
{
  "message": "Logged out successfully"
}
```

---

### POST /auth/logout-all
Logout from all devices.

**Response:** `200 OK`
```json
{
  "message": "Logged out from all devices"
}
```

---

## Investment Endpoints

### GET /investments
List investments with filters and pagination.

**Query Parameters:**
| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| page | number | 1 | Page number |
| limit | number | 10 | Items per page (max 50) |
| category | string | - | Filter by category |
| riskLevel | string | - | Filter by risk (Low, Medium, High) |
| status | string | active | Filter by status |
| minInvestment | number | - | Minimum investment filter |
| maxInvestment | number | - | Maximum investment filter |
| sortBy | string | newest | Sort order |

**Sort Options:** `newest`, `endingSoon`, `mostFunded`, `highestROI`

**Response:** `200 OK`
```json
{
  "data": [
    {
      "id": "uuid",
      "name": "NeuroLink Diagnostics",
      "description": "AI-powered early detection...",
      "category": "Digital Health",
      "fundingGoal": 2500000,
      "fundingCurrent": 1875000,
      "minimumInvestment": 1000,
      "expectedROI": "15-22%",
      "riskLevel": "Medium",
      "status": "active",
      "imageUrl": "https://...",
      "daysRemaining": 45,
      "investors": 342,
      "createdAt": "2025-01-01T00:00:00Z"
    }
  ],
  "page": 1,
  "limit": 10,
  "totalItems": 45,
  "totalPages": 5,
  "hasMore": true
}
```

---

### GET /investments/search
Search investments by name or description.

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| q | string | Search query (min 2 chars) |
| page | number | Page number |
| limit | number | Items per page |
| category | string | Filter by category |
| riskLevel | string | Filter by risk level |

**Response:** Same as `/investments`

---

### GET /investments/:id
Get investment detail with team, documents, and milestones.

**Response:** `200 OK`
```json
{
  "id": "uuid",
  "name": "NeuroLink Diagnostics",
  "description": "Short description...",
  "longDescription": "Full description with details...",
  "category": "Digital Health",
  "fundingGoal": 2500000,
  "fundingCurrent": 1875000,
  "minimumInvestment": 1000,
  "expectedROI": "15-22%",
  "riskLevel": "Medium",
  "status": "active",
  "imageUrl": "https://...",
  "daysRemaining": 45,
  "startDate": "2024-10-01T00:00:00Z",
  "endDate": "2025-03-01T00:00:00Z",
  "investors": 342,
  "documents": [
    {
      "id": "uuid",
      "name": "Investment Prospectus",
      "type": "pdf",
      "url": "/documents/prospectus.pdf"
    }
  ],
  "team": [
    {
      "id": "uuid",
      "name": "Dr. Sarah Chen",
      "role": "CEO & Co-Founder",
      "avatarUrl": "https://...",
      "linkedInUrl": "https://linkedin.com/in/..."
    }
  ],
  "milestones": [
    {
      "id": "uuid",
      "title": "FDA 510(k) Clearance",
      "description": "Received FDA clearance",
      "completed": true,
      "completedAt": "2024-06-15T00:00:00Z"
    },
    {
      "id": "uuid",
      "title": "Commercial Launch",
      "description": "Full commercial availability",
      "completed": false,
      "targetDate": "2025-06-01T00:00:00Z"
    }
  ]
}
```

---

### GET /investments/categories/stats
Get investment counts by category.

**Response:** `200 OK`
```json
[
  { "category": "Digital Health", "count": 15 },
  { "category": "Biotech", "count": 12 },
  { "category": "Medical Devices", "count": 8 }
]
```

---

## Portfolio Endpoints

### GET /portfolio/summary
Get portfolio summary with totals.

**Response:** `200 OK`
```json
{
  "totalValue": 125000,
  "totalInvested": 100000,
  "totalGainLoss": 25000,
  "gainLossPercent": 25.0,
  "activeInvestments": 5,
  "completedInvestments": 2,
  "pendingInvestments": 1
}
```

---

### GET /portfolio/investments
Get user's investments with pagination.

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| page | number | Page number |
| limit | number | Items per page (max 50) |
| status | string | Filter by status |

**Response:** `200 OK`
```json
{
  "data": [
    {
      "id": "uuid",
      "investmentId": "uuid",
      "name": "NeuroLink Diagnostics",
      "category": "Digital Health",
      "imageUrl": "https://...",
      "amountInvested": 5000,
      "currentValue": 6250,
      "gainLossPercent": 25.0,
      "status": "active",
      "investedAt": "2024-11-15T00:00:00Z"
    }
  ],
  "page": 1,
  "limit": 20,
  "totalItems": 8,
  "totalPages": 1,
  "hasMore": false
}
```

---

### POST /portfolio/invest
Create a new investment.

**Request Body:**
```json
{
  "investmentId": "uuid",
  "amount": 5000,
  "paymentMethodId": "uuid"
}
```

**Response:** `201 Created`
```json
{
  "message": "Investment submitted successfully",
  "portfolioInvestment": {
    "id": "uuid",
    "investmentId": "uuid",
    "amountInvested": 5000,
    "status": "pending"
  },
  "transaction": {
    "id": "uuid",
    "amount": 5000,
    "status": "pending"
  }
}
```

**Errors:**
- `400` - Invalid amount or below minimum
- `404` - Investment or payment method not found

---

### GET /portfolio/transactions
Get transaction history.

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| page | number | Page number |
| limit | number | Items per page |
| type | string | Filter: investment, dividend, withdrawal, refund |

**Response:** `200 OK`
```json
{
  "data": [
    {
      "id": "uuid",
      "type": "investment",
      "amount": 5000,
      "status": "completed",
      "investmentName": "NeuroLink Diagnostics",
      "createdAt": "2024-11-15T00:00:00Z",
      "completedAt": "2024-11-15T00:05:00Z"
    }
  ],
  "page": 1,
  "limit": 20,
  "totalItems": 15,
  "totalPages": 1,
  "hasMore": false
}
```

---

## Article Endpoints

### GET /articles
List articles with filters and pagination.

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| page | number | Page number |
| limit | number | Items per page (max 50) |
| category | string | Filter by category |
| featured | boolean | Filter featured only |
| search | string | Search in title/summary |
| sortBy | string | newest, popular, readTime |

**Response:** `200 OK`
```json
{
  "data": [
    {
      "id": "uuid",
      "title": "AI in Healthcare: The Next Frontier",
      "summary": "How artificial intelligence...",
      "source": "MedInvest Research",
      "author": "Dr. Rachel Martinez",
      "imageUrl": "https://...",
      "category": "AI & Healthcare",
      "tags": ["AI", "Diagnostics", "Investment"],
      "readTime": 8,
      "isFeatured": true,
      "isBookmarked": false,
      "viewCount": 1234,
      "publishedAt": "2025-01-10T00:00:00Z"
    }
  ],
  "page": 1,
  "limit": 15,
  "totalItems": 45,
  "totalPages": 3,
  "hasMore": true
}
```

---

### GET /articles/bookmarked
Get user's bookmarked articles.

**Response:** Same format as `/articles`

---

### GET /articles/:id
Get article detail with full content.

**Response:** `200 OK`
```json
{
  "id": "uuid",
  "title": "AI in Healthcare: The Next Frontier",
  "summary": "How artificial intelligence...",
  "content": "Full article content here...",
  "source": "MedInvest Research",
  "sourceUrl": "https://...",
  "author": "Dr. Rachel Martinez",
  "imageUrl": "https://...",
  "category": "AI & Healthcare",
  "tags": ["AI", "Diagnostics", "Investment"],
  "readTime": 8,
  "isFeatured": true,
  "isBookmarked": false,
  "viewCount": 1235,
  "publishedAt": "2025-01-10T00:00:00Z"
}
```

---

### POST /articles/:id/bookmark
Toggle article bookmark.

**Response:** `200 OK`
```json
{
  "isBookmarked": true,
  "message": "Article bookmarked"
}
```

---

## User Endpoints

### GET /users/me
Get current user profile (alias for /auth/me).

---

### PATCH /users/me
Update user profile.

**Request Body:**
```json
{
  "firstName": "John",
  "lastName": "Doe",
  "phone": "+1234567890"
}
```

---

### POST /users/me/avatar
Upload user avatar.

**Request:** `multipart/form-data`
- `avatar`: Image file (JPEG, PNG, WebP, max 5MB)

**Response:** `200 OK`
```json
{
  "avatarUrl": "/uploads/avatars/uuid-123.jpg"
}
```

---

### POST /users/me/push-token
Register push notification token.

**Request Body:**
```json
{
  "token": "ExponentPushToken[...]",
  "platform": "ios" | "android"
}
```

**Response:** `200 OK`
```json
{
  "message": "Push token registered"
}
```

---

### DELETE /users/me/push-token
Unregister push notification token.

**Request Body:**
```json
{
  "token": "ExponentPushToken[...]"
}
```

---

### GET /users/me/notification-preferences
Get notification preferences.

**Response:** `200 OK`
```json
{
  "investmentUpdates": true,
  "newOpportunities": true,
  "portfolioMilestones": true,
  "articles": false,
  "marketing": false
}
```

---

### PATCH /users/me/notification-preferences
Update notification preferences.

**Request Body:**
```json
{
  "investmentUpdates": true,
  "articles": true
}
```

---

### GET /users/me/payment-methods
Get user's payment methods.

**Response:** `200 OK`
```json
[
  {
    "id": "uuid",
    "type": "bank",
    "name": "Chase Checking",
    "last4": "4567",
    "bankName": "Chase",
    "isDefault": true
  },
  {
    "id": "uuid",
    "type": "card",
    "name": "Visa ending in 1234",
    "last4": "1234",
    "expiryMonth": 12,
    "expiryYear": 2027,
    "isDefault": false
  }
]
```

---

## Error Responses

All errors follow this format:

```json
{
  "message": "Error description",
  "errors": {
    "field": "Field-specific error"
  }
}
```

### HTTP Status Codes

| Code | Description |
|------|-------------|
| 200 | Success |
| 201 | Created |
| 400 | Bad Request - Invalid input |
| 401 | Unauthorized - Invalid/missing token |
| 403 | Forbidden - Insufficient permissions |
| 404 | Not Found |
| 422 | Unprocessable Entity - Validation error |
| 500 | Internal Server Error |

---

## Rate Limiting

- **Authenticated**: 1000 requests/hour
- **Unauthenticated**: 100 requests/hour

Rate limit headers:
```
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 999
X-RateLimit-Reset: 1704067200
```

---

## Pagination

All list endpoints support pagination:

```json
{
  "data": [...],
  "page": 1,
  "limit": 10,
  "totalItems": 100,
  "totalPages": 10,
  "hasMore": true
}
```

Use `page` and `limit` query parameters to paginate.
