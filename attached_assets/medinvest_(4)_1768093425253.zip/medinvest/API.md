# MedInvest Mobile API Documentation

**Base URL:** `https://your-domain.com/api/v1`

**Version:** 1.0

## Authentication

All authenticated endpoints require a Bearer token in the Authorization header:

```
Authorization: Bearer <access_token>
```

### Register

```http
POST /auth/register
Content-Type: application/json

{
  "email": "doctor@example.com",
  "password": "securepassword",
  "first_name": "John",
  "last_name": "Smith",
  "specialty": "cardiology"
}
```

**Response (201):**
```json
{
  "message": "Registration successful",
  "user": { ... },
  "access_token": "eyJ...",
  "refresh_token": "eyJ..."
}
```

### Login

```http
POST /auth/login
Content-Type: application/json

{
  "email": "doctor@example.com",
  "password": "securepassword"
}
```

**Response (200):**
```json
{
  "user": {
    "id": 1,
    "email": "doctor@example.com",
    "first_name": "John",
    "last_name": "Smith",
    "specialty": "cardiology",
    "is_verified": true,
    "is_premium": false,
    "level": 5,
    "points": 1250
  },
  "access_token": "eyJ...",
  "refresh_token": "eyJ..."
}
```

### Refresh Token

```http
POST /auth/refresh
Content-Type: application/json

{
  "refresh_token": "eyJ..."
}
```

**Response (200):**
```json
{
  "access_token": "eyJ...",
  "refresh_token": "eyJ..."
}
```

### Get Current User

```http
GET /auth/me
Authorization: Bearer <token>
```

**Response (200):**
```json
{
  "id": 1,
  "email": "doctor@example.com",
  "first_name": "John",
  "last_name": "Smith",
  "specialty": "cardiology",
  "stats": {
    "followers": 45,
    "following": 23,
    "posts": 12,
    "points": 1250,
    "level": 5
  }
}
```

---

## Feed

### Get Feed

```http
GET /feed?page=1&per_page=20&style=algorithmic
Authorization: Bearer <token>
```

**Query Parameters:**
| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| page | int | 1 | Page number |
| per_page | int | 20 | Items per page (max 100) |
| style | string | algorithmic | Feed style: `algorithmic`, `chronological`, `following` |

**Response (200):**
```json
{
  "posts": [
    {
      "id": 123,
      "content": "Just hit my first $1M in index funds!",
      "is_anonymous": false,
      "author": {
        "id": 1,
        "first_name": "John",
        "last_name": "Smith",
        "specialty": "cardiology",
        "is_verified": true,
        "level": 5
      },
      "room": {
        "id": 1,
        "name": "Index Fund Investors",
        "slug": "index-funds"
      },
      "upvotes": 45,
      "downvotes": 2,
      "score": 43,
      "comment_count": 12,
      "view_count": 234,
      "media": [],
      "user_vote": 1,
      "is_bookmarked": false,
      "created_at": "2024-01-15T10:30:00Z",
      "time_ago": "2h ago"
    }
  ],
  "meta": {
    "page": 1,
    "per_page": 20,
    "total": 150,
    "pages": 8,
    "has_next": true,
    "has_prev": false
  }
}
```

### Get Trending

```http
GET /feed/trending?hours=24&limit=10
```

---

## Posts

### Create Post

```http
POST /posts
Authorization: Bearer <token>
Content-Type: application/json

{
  "content": "Great discussion on backdoor Roth today! #retirement",
  "room_id": 1,
  "is_anonymous": false
}
```

**Response (201):**
```json
{
  "id": 124,
  "content": "Great discussion on backdoor Roth today! #retirement",
  ...
}
```

### Get Post

```http
GET /posts/123
```

**Response (200):**
```json
{
  "post": { ... },
  "comments": [
    {
      "id": 1,
      "content": "Congrats!",
      "author": { ... },
      "upvotes": 5,
      "created_at": "2024-01-15T11:00:00Z",
      "time_ago": "1h ago"
    }
  ]
}
```

### Delete Post

```http
DELETE /posts/123
Authorization: Bearer <token>
```

### Vote on Post

```http
POST /posts/123/vote
Authorization: Bearer <token>
Content-Type: application/json

{
  "vote": 1
}
```

**Vote values:** `1` (upvote), `-1` (downvote), `0` (remove vote)

**Response (200):**
```json
{
  "upvotes": 46,
  "downvotes": 2,
  "score": 44,
  "user_vote": 1
}
```

### Bookmark Post

```http
POST /posts/123/bookmark
Authorization: Bearer <token>
```

**Response (200):**
```json
{
  "is_bookmarked": true
}
```

### Add Comment

```http
POST /posts/123/comments
Authorization: Bearer <token>
Content-Type: application/json

{
  "content": "Great advice!",
  "parent_id": null,
  "is_anonymous": false
}
```

---

## Rooms

### List Rooms

```http
GET /rooms
```

**Response (200):**
```json
{
  "rooms": [
    {
      "id": 1,
      "name": "Index Fund Investors",
      "slug": "index-funds",
      "description": "Passive investing with index funds",
      "category": "Strategy",
      "icon": "chart-line",
      "member_count": 1234
    }
  ]
}
```

### Get Room with Posts

```http
GET /rooms/index-funds?page=1&per_page=20
```

---

## Users

### Get User Profile

```http
GET /users/1
```

**Response (200):**
```json
{
  "id": 1,
  "first_name": "John",
  "last_name": "Smith",
  "specialty": "cardiology",
  "is_verified": true,
  "level": 5,
  "stats": {
    "followers": 45,
    "following": 23,
    "posts": 12
  },
  "is_following": true
}
```

### Get User's Posts

```http
GET /users/1/posts?page=1
```

### Follow/Unfollow User

```http
POST /users/1/follow
Authorization: Bearer <token>
```

**Response (200):**
```json
{
  "is_following": true,
  "follower_count": 46
}
```

---

## Notifications

### List Notifications

```http
GET /notifications?page=1&unread_only=false
Authorization: Bearer <token>
```

**Response (200):**
```json
{
  "notifications": [
    {
      "id": 1,
      "type": "mention",
      "title": "You were mentioned!",
      "message": "John Smith mentioned you in a post",
      "url": "/rooms/post/123",
      "is_read": false,
      "actor": { ... },
      "created_at": "2024-01-15T10:30:00Z",
      "time_ago": "2h ago"
    }
  ],
  "meta": { ... },
  "unread_count": 5
}
```

### Get Unread Count

```http
GET /notifications/unread-count
Authorization: Bearer <token>
```

**Response (200):**
```json
{
  "count": 5
}
```

### Mark as Read

```http
POST /notifications/123/read
Authorization: Bearer <token>
```

### Mark All as Read

```http
POST /notifications/read-all
Authorization: Bearer <token>
```

---

## Push Notifications

### Register Device Token

```http
POST /push/register
Authorization: Bearer <token>
Content-Type: application/json

{
  "token": "fcm_token_or_apns_token",
  "platform": "ios",
  "device_id": "unique_device_id"
}
```

### Unregister Token

```http
POST /push/unregister
Authorization: Bearer <token>
Content-Type: application/json

{
  "token": "fcm_token_or_apns_token"
}
```

---

## Search

```http
GET /search?q=backdoor%20roth&type=all
```

**Query Parameters:**
| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| q | string | required | Search query |
| type | string | all | Search type: `all`, `posts`, `users`, `hashtags` |

**Response (200):**
```json
{
  "posts": [ ... ],
  "users": [ ... ],
  "hashtags": [
    { "name": "backdoorroth", "post_count": 45 }
  ]
}
```

---

## Bookmarks

```http
GET /bookmarks?page=1
Authorization: Bearer <token>
```

---

## AMAs

```http
GET /amas
```

**Response (200):**
```json
{
  "upcoming": [
    {
      "id": 1,
      "title": "Real Estate Investing for Physicians",
      "expert_name": "Dr. Sarah Real Estate",
      "scheduled_for": "2024-01-20T18:00:00Z",
      "duration_minutes": 60,
      "is_premium_only": false
    }
  ],
  "past": [ ... ]
}
```

---

## Deals (Premium Only)

```http
GET /deals
Authorization: Bearer <token>
```

**Response (200 / 403 if not premium):**
```json
{
  "deals": [
    {
      "id": 1,
      "title": "Medical Office Building - Austin, TX",
      "deal_type": "real_estate",
      "minimum_investment": 50000,
      "projected_return": "12-15%",
      "investment_term": "5 years",
      "location": "Austin, TX",
      "is_featured": true
    }
  ]
}
```

---

## Error Responses

All errors follow this format:

```json
{
  "error": "Error message",
  "code": "ERROR_CODE"
}
```

### Common Error Codes

| Code | Status | Description |
|------|--------|-------------|
| TOKEN_MISSING | 401 | No authorization token provided |
| TOKEN_EXPIRED | 401 | Token has expired |
| TOKEN_INVALID | 401 | Token is invalid |
| USER_NOT_FOUND | 401 | User in token no longer exists |

---

## Rate Limits

| Endpoint | Limit |
|----------|-------|
| Authentication | 10 requests/minute |
| General API | 100 requests/minute |
| Search | 30 requests/minute |

---

## Mobile Implementation Notes

### iOS (Swift)

```swift
// Store tokens securely in Keychain
let accessToken = KeychainWrapper.standard.string(forKey: "accessToken")

// Add to requests
var request = URLRequest(url: url)
request.setValue("Bearer \(accessToken)", forHTTPHeaderField: "Authorization")

// Handle 401 - refresh token
if response.statusCode == 401 {
    refreshToken { newToken in
        // Retry request
    }
}
```

### Android (Kotlin)

```kotlin
// OkHttp Interceptor
class AuthInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val token = TokenManager.getAccessToken()
        val request = chain.request().newBuilder()
            .addHeader("Authorization", "Bearer $token")
            .build()
        return chain.proceed(request)
    }
}

// Handle token refresh in Authenticator
class TokenAuthenticator : Authenticator {
    override fun authenticate(route: Route?, response: Response): Request? {
        val newToken = refreshToken() ?: return null
        return response.request.newBuilder()
            .header("Authorization", "Bearer $newToken")
            .build()
    }
}
```

### React Native

```javascript
// API client setup
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

const api = axios.create({
  baseURL: 'https://api.medinvest.com/api/v1',
});

api.interceptors.request.use(async (config) => {
  const token = await AsyncStorage.getItem('accessToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use(
  (response) => response,
  async (error) => {
    if (error.response?.status === 401) {
      const refreshToken = await AsyncStorage.getItem('refreshToken');
      const { data } = await api.post('/auth/refresh', { refresh_token: refreshToken });
      await AsyncStorage.setItem('accessToken', data.access_token);
      error.config.headers.Authorization = `Bearer ${data.access_token}`;
      return api.request(error.config);
    }
    return Promise.reject(error);
  }
);
```

---

## Push Notification Payload

When sending push notifications to mobile devices, use this payload format:

### FCM (Android)

```json
{
  "to": "<device_token>",
  "notification": {
    "title": "New mention!",
    "body": "John Smith mentioned you in a post"
  },
  "data": {
    "type": "mention",
    "url": "/rooms/post/123",
    "post_id": "123"
  }
}
```

### APNs (iOS)

```json
{
  "aps": {
    "alert": {
      "title": "New mention!",
      "body": "John Smith mentioned you in a post"
    },
    "badge": 5,
    "sound": "default"
  },
  "data": {
    "type": "mention",
    "url": "/rooms/post/123"
  }
}
```
