"""
Mobile API - RESTful API for iOS/Android apps
JWT authentication, versioned endpoints, rate limiting
"""
import os
import jwt
import functools
from datetime import datetime, timedelta
from flask import Blueprint, request, jsonify, g, current_app
from werkzeug.security import check_password_hash
from app import db
from models import (
    User, Post, PostVote, Comment, Room, Bookmark, Notification,
    NotificationType, PushSubscription, UserFollow, Hashtag,
    PostMedia, ExpertAMA, InvestmentDeal, Course, Event
)

api_bp = Blueprint('api', __name__, url_prefix='/api/v1')

# =============================================================================
# CONFIGURATION
# =============================================================================

JWT_SECRET = os.environ.get('JWT_SECRET', 'medinvest-jwt-secret-change-in-production')
JWT_EXPIRY_HOURS = 24 * 7  # 7 days
REFRESH_TOKEN_DAYS = 30


# =============================================================================
# AUTHENTICATION DECORATOR
# =============================================================================

def token_required(f):
    """Decorator to require valid JWT token"""
    @functools.wraps(f)
    def decorated(*args, **kwargs):
        token = None
        
        # Get token from header
        auth_header = request.headers.get('Authorization')
        if auth_header and auth_header.startswith('Bearer '):
            token = auth_header.split(' ')[1]
        
        if not token:
            return jsonify({'error': 'Token is missing', 'code': 'TOKEN_MISSING'}), 401
        
        try:
            payload = jwt.decode(token, JWT_SECRET, algorithms=['HS256'])
            g.current_user = User.query.get(payload['user_id'])
            
            if not g.current_user:
                return jsonify({'error': 'User not found', 'code': 'USER_NOT_FOUND'}), 401
                
        except jwt.ExpiredSignatureError:
            return jsonify({'error': 'Token has expired', 'code': 'TOKEN_EXPIRED'}), 401
        except jwt.InvalidTokenError:
            return jsonify({'error': 'Invalid token', 'code': 'TOKEN_INVALID'}), 401
        
        return f(*args, **kwargs)
    return decorated


def optional_token(f):
    """Decorator for optional authentication"""
    @functools.wraps(f)
    def decorated(*args, **kwargs):
        token = None
        auth_header = request.headers.get('Authorization')
        
        if auth_header and auth_header.startswith('Bearer '):
            token = auth_header.split(' ')[1]
            try:
                payload = jwt.decode(token, JWT_SECRET, algorithms=['HS256'])
                g.current_user = User.query.get(payload['user_id'])
            except:
                g.current_user = None
        else:
            g.current_user = None
        
        return f(*args, **kwargs)
    return decorated


def generate_tokens(user):
    """Generate access and refresh tokens"""
    access_token = jwt.encode({
        'user_id': user.id,
        'exp': datetime.utcnow() + timedelta(hours=JWT_EXPIRY_HOURS),
        'type': 'access'
    }, JWT_SECRET, algorithm='HS256')
    
    refresh_token = jwt.encode({
        'user_id': user.id,
        'exp': datetime.utcnow() + timedelta(days=REFRESH_TOKEN_DAYS),
        'type': 'refresh'
    }, JWT_SECRET, algorithm='HS256')
    
    return access_token, refresh_token


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def serialize_user(user, include_email=False):
    """Serialize user object for API response"""
    data = {
        'id': user.id,
        'first_name': user.first_name,
        'last_name': user.last_name,
        'full_name': user.full_name,
        'specialty': user.specialty,
        'specialty_display': user.specialty_display,
        'is_verified': user.is_verified,
        'is_premium': user.is_premium,
        'level': user.level,
        'points': user.points,
        'avatar_url': user.avatar_url,
        'created_at': user.created_at.isoformat()
    }
    
    if include_email:
        data['email'] = user.email
    
    return data


def serialize_post(post, current_user=None):
    """Serialize post object for API response"""
    # Get user's vote if authenticated
    user_vote = None
    is_bookmarked = False
    
    if current_user:
        vote = PostVote.query.filter_by(post_id=post.id, user_id=current_user.id).first()
        user_vote = vote.vote_type if vote else None
        is_bookmarked = Bookmark.query.filter_by(post_id=post.id, user_id=current_user.id).first() is not None
    
    # Get media
    media = [{
        'id': m.id,
        'type': m.media_type,
        'url': m.file_url,
        'thumbnail_url': m.thumbnail_url
    } for m in post.media]
    
    data = {
        'id': post.id,
        'content': post.content,
        'is_anonymous': post.is_anonymous,
        'author': serialize_user(post.author) if not post.is_anonymous else None,
        'anonymous_name': post.anonymous_name if post.is_anonymous else None,
        'display_author': post.display_author,
        'room': {
            'id': post.room.id,
            'name': post.room.name,
            'slug': post.room.slug
        } if post.room else None,
        'upvotes': post.upvotes,
        'downvotes': post.downvotes,
        'score': post.upvotes - post.downvotes,
        'comment_count': post.comment_count,
        'view_count': post.view_count,
        'media': media,
        'media_count': post.media_count,
        'user_vote': user_vote,
        'is_bookmarked': is_bookmarked,
        'created_at': post.created_at.isoformat(),
        'time_ago': get_time_ago(post.created_at)
    }
    
    return data


def serialize_comment(comment):
    """Serialize comment object"""
    return {
        'id': comment.id,
        'content': comment.content,
        'author': serialize_user(comment.author) if not comment.is_anonymous else None,
        'is_anonymous': comment.is_anonymous,
        'anonymous_name': comment.anonymous_name,
        'upvotes': comment.upvotes,
        'parent_id': comment.parent_id,
        'created_at': comment.created_at.isoformat(),
        'time_ago': get_time_ago(comment.created_at)
    }


def serialize_notification(notification):
    """Serialize notification object"""
    return {
        'id': notification.id,
        'type': notification.notification_type.value,
        'title': notification.title,
        'message': notification.message,
        'url': notification.url,
        'is_read': notification.is_read,
        'actor': serialize_user(notification.actor) if notification.actor else None,
        'created_at': notification.created_at.isoformat(),
        'time_ago': get_time_ago(notification.created_at)
    }


def get_time_ago(dt):
    """Get human-readable time ago string"""
    now = datetime.utcnow()
    diff = now - dt
    
    if diff.days > 365:
        years = diff.days // 365
        return f"{years}y ago"
    elif diff.days > 30:
        months = diff.days // 30
        return f"{months}mo ago"
    elif diff.days > 0:
        return f"{diff.days}d ago"
    elif diff.seconds > 3600:
        hours = diff.seconds // 3600
        return f"{hours}h ago"
    elif diff.seconds > 60:
        minutes = diff.seconds // 60
        return f"{minutes}m ago"
    else:
        return "just now"


def paginate(query, page=1, per_page=20, max_per_page=100):
    """Paginate a query and return metadata"""
    per_page = min(per_page, max_per_page)
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    
    return {
        'items': pagination.items,
        'meta': {
            'page': page,
            'per_page': per_page,
            'total': pagination.total,
            'pages': pagination.pages,
            'has_next': pagination.has_next,
            'has_prev': pagination.has_prev
        }
    }


# =============================================================================
# AUTH ENDPOINTS
# =============================================================================

@api_bp.route('/auth/register', methods=['POST'])
def register():
    """Register a new user"""
    data = request.get_json()
    
    required = ['email', 'password', 'first_name', 'last_name']
    for field in required:
        if not data.get(field):
            return jsonify({'error': f'{field} is required'}), 400
    
    if User.query.filter_by(email=data['email'].lower()).first():
        return jsonify({'error': 'Email already registered'}), 409
    
    user = User(
        email=data['email'].lower(),
        first_name=data['first_name'],
        last_name=data['last_name'],
        specialty=data.get('specialty')
    )
    user.set_password(data['password'])
    user.generate_referral_code()
    
    db.session.add(user)
    db.session.commit()
    
    access_token, refresh_token = generate_tokens(user)
    
    return jsonify({
        'message': 'Registration successful',
        'user': serialize_user(user, include_email=True),
        'access_token': access_token,
        'refresh_token': refresh_token
    }), 201


@api_bp.route('/auth/login', methods=['POST'])
def login():
    """Login and get JWT tokens"""
    data = request.get_json()
    
    if not data.get('email') or not data.get('password'):
        return jsonify({'error': 'Email and password required'}), 400
    
    user = User.query.filter_by(email=data['email'].lower()).first()
    
    if not user or not user.check_password(data['password']):
        return jsonify({'error': 'Invalid email or password'}), 401
    
    # Update last login
    user.last_login = datetime.utcnow()
    db.session.commit()
    
    access_token, refresh_token = generate_tokens(user)
    
    return jsonify({
        'user': serialize_user(user, include_email=True),
        'access_token': access_token,
        'refresh_token': refresh_token
    })


@api_bp.route('/auth/refresh', methods=['POST'])
def refresh_token():
    """Refresh access token"""
    data = request.get_json()
    token = data.get('refresh_token')
    
    if not token:
        return jsonify({'error': 'Refresh token required'}), 400
    
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=['HS256'])
        
        if payload.get('type') != 'refresh':
            return jsonify({'error': 'Invalid token type'}), 401
        
        user = User.query.get(payload['user_id'])
        if not user:
            return jsonify({'error': 'User not found'}), 401
        
        access_token, new_refresh_token = generate_tokens(user)
        
        return jsonify({
            'access_token': access_token,
            'refresh_token': new_refresh_token
        })
        
    except jwt.ExpiredSignatureError:
        return jsonify({'error': 'Refresh token expired'}), 401
    except jwt.InvalidTokenError:
        return jsonify({'error': 'Invalid token'}), 401


@api_bp.route('/auth/me', methods=['GET'])
@token_required
def get_current_user():
    """Get current authenticated user"""
    user = g.current_user
    
    # Get additional stats
    follower_count = UserFollow.query.filter_by(following_id=user.id).count()
    following_count = UserFollow.query.filter_by(follower_id=user.id).count()
    post_count = Post.query.filter_by(user_id=user.id).count()
    
    data = serialize_user(user, include_email=True)
    data['stats'] = {
        'followers': follower_count,
        'following': following_count,
        'posts': post_count,
        'points': user.points,
        'level': user.level
    }
    
    return jsonify(data)


@api_bp.route('/auth/me', methods=['PATCH'])
@token_required
def update_current_user():
    """Update current user profile"""
    user = g.current_user
    data = request.get_json()
    
    allowed_fields = ['first_name', 'last_name', 'specialty', 'bio']
    
    for field in allowed_fields:
        if field in data:
            setattr(user, field, data[field])
    
    db.session.commit()
    
    return jsonify(serialize_user(user, include_email=True))


# =============================================================================
# FEED ENDPOINTS
# =============================================================================

@api_bp.route('/feed', methods=['GET'])
@token_required
def get_feed():
    """Get personalized feed"""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    style = request.args.get('style', 'algorithmic')  # algorithmic, chronological, following
    
    user = g.current_user
    
    if style == 'following':
        # Posts from followed users
        following_ids = [f.following_id for f in UserFollow.query.filter_by(follower_id=user.id).all()]
        following_ids.append(user.id)
        query = Post.query.filter(Post.user_id.in_(following_ids))
    else:
        query = Post.query
    
    query = query.order_by(Post.created_at.desc())
    result = paginate(query, page, per_page)
    
    posts = [serialize_post(p, user) for p in result['items']]
    
    return jsonify({
        'posts': posts,
        'meta': result['meta']
    })


@api_bp.route('/feed/trending', methods=['GET'])
@optional_token
def get_trending():
    """Get trending posts"""
    hours = request.args.get('hours', 24, type=int)
    limit = request.args.get('limit', 10, type=int)
    
    cutoff = datetime.utcnow() - timedelta(hours=hours)
    
    posts = Post.query.filter(Post.created_at >= cutoff)\
        .order_by((Post.upvotes + Post.comment_count * 2).desc())\
        .limit(min(limit, 50)).all()
    
    return jsonify({
        'posts': [serialize_post(p, g.current_user) for p in posts]
    })


# =============================================================================
# POST ENDPOINTS
# =============================================================================

@api_bp.route('/posts', methods=['POST'])
@token_required
def create_post():
    """Create a new post"""
    data = request.get_json()
    
    if not data.get('content'):
        return jsonify({'error': 'Content is required'}), 400
    
    post = Post(
        user_id=g.current_user.id,
        content=data['content'],
        room_id=data.get('room_id'),
        is_anonymous=data.get('is_anonymous', False),
        anonymous_name=data.get('anonymous_name') if data.get('is_anonymous') else None
    )
    
    db.session.add(post)
    
    # Award points
    g.current_user.add_points(5)
    
    db.session.commit()
    
    return jsonify(serialize_post(post, g.current_user)), 201


@api_bp.route('/posts/<int:post_id>', methods=['GET'])
@optional_token
def get_post(post_id):
    """Get a single post with comments"""
    post = Post.query.get_or_404(post_id)
    
    # Increment view count
    post.view_count += 1
    db.session.commit()
    
    # Get comments
    comments = Comment.query.filter_by(post_id=post_id)\
        .order_by(Comment.created_at.asc()).all()
    
    return jsonify({
        'post': serialize_post(post, g.current_user),
        'comments': [serialize_comment(c) for c in comments]
    })


@api_bp.route('/posts/<int:post_id>', methods=['DELETE'])
@token_required
def delete_post(post_id):
    """Delete a post (owner only)"""
    post = Post.query.get_or_404(post_id)
    
    if post.user_id != g.current_user.id and not g.current_user.is_admin:
        return jsonify({'error': 'Unauthorized'}), 403
    
    db.session.delete(post)
    db.session.commit()
    
    return jsonify({'message': 'Post deleted'})


@api_bp.route('/posts/<int:post_id>/vote', methods=['POST'])
@token_required
def vote_post(post_id):
    """Vote on a post (1 = upvote, -1 = downvote, 0 = remove)"""
    post = Post.query.get_or_404(post_id)
    data = request.get_json()
    vote_type = data.get('vote', 0)
    
    if vote_type not in [-1, 0, 1]:
        return jsonify({'error': 'Invalid vote type'}), 400
    
    existing = PostVote.query.filter_by(
        post_id=post_id,
        user_id=g.current_user.id
    ).first()
    
    if vote_type == 0:
        # Remove vote
        if existing:
            if existing.vote_type == 1:
                post.upvotes -= 1
            else:
                post.downvotes -= 1
            db.session.delete(existing)
    elif existing:
        # Change vote
        if existing.vote_type != vote_type:
            if vote_type == 1:
                post.upvotes += 1
                post.downvotes -= 1
            else:
                post.downvotes += 1
                post.upvotes -= 1
            existing.vote_type = vote_type
    else:
        # New vote
        vote = PostVote(post_id=post_id, user_id=g.current_user.id, vote_type=vote_type)
        if vote_type == 1:
            post.upvotes += 1
        else:
            post.downvotes += 1
        db.session.add(vote)
    
    db.session.commit()
    
    return jsonify({
        'upvotes': post.upvotes,
        'downvotes': post.downvotes,
        'score': post.upvotes - post.downvotes,
        'user_vote': vote_type if vote_type != 0 else None
    })


@api_bp.route('/posts/<int:post_id>/bookmark', methods=['POST'])
@token_required
def toggle_bookmark(post_id):
    """Toggle bookmark on a post"""
    post = Post.query.get_or_404(post_id)
    
    existing = Bookmark.query.filter_by(
        post_id=post_id,
        user_id=g.current_user.id
    ).first()
    
    if existing:
        db.session.delete(existing)
        is_bookmarked = False
    else:
        bookmark = Bookmark(post_id=post_id, user_id=g.current_user.id)
        db.session.add(bookmark)
        is_bookmarked = True
    
    db.session.commit()
    
    return jsonify({'is_bookmarked': is_bookmarked})


@api_bp.route('/posts/<int:post_id>/comments', methods=['POST'])
@token_required
def add_comment(post_id):
    """Add a comment to a post"""
    post = Post.query.get_or_404(post_id)
    data = request.get_json()
    
    if not data.get('content'):
        return jsonify({'error': 'Content is required'}), 400
    
    comment = Comment(
        post_id=post_id,
        user_id=g.current_user.id,
        content=data['content'],
        parent_id=data.get('parent_id'),
        is_anonymous=data.get('is_anonymous', False)
    )
    
    db.session.add(comment)
    post.comment_count += 1
    g.current_user.add_points(2)
    
    db.session.commit()
    
    # Send notification to post author
    if not post.is_anonymous and post.user_id != g.current_user.id:
        from routes.notifications import notify_comment
        notify_comment(post.user_id, g.current_user, post, comment)
    
    return jsonify(serialize_comment(comment)), 201


# =============================================================================
# ROOM ENDPOINTS
# =============================================================================

@api_bp.route('/rooms', methods=['GET'])
@optional_token
def get_rooms():
    """Get all rooms"""
    rooms = Room.query.order_by(Room.member_count.desc()).all()
    
    return jsonify({
        'rooms': [{
            'id': r.id,
            'name': r.name,
            'slug': r.slug,
            'description': r.description,
            'category': r.category,
            'icon': r.icon,
            'member_count': r.member_count
        } for r in rooms]
    })


@api_bp.route('/rooms/<slug>', methods=['GET'])
@optional_token
def get_room(slug):
    """Get room details with posts"""
    room = Room.query.filter_by(slug=slug).first_or_404()
    
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    
    query = Post.query.filter_by(room_id=room.id).order_by(Post.created_at.desc())
    result = paginate(query, page, per_page)
    
    return jsonify({
        'room': {
            'id': room.id,
            'name': room.name,
            'slug': room.slug,
            'description': room.description,
            'category': room.category,
            'icon': room.icon,
            'member_count': room.member_count
        },
        'posts': [serialize_post(p, g.current_user) for p in result['items']],
        'meta': result['meta']
    })


# =============================================================================
# USER ENDPOINTS
# =============================================================================

@api_bp.route('/users/<int:user_id>', methods=['GET'])
@optional_token
def get_user(user_id):
    """Get user profile"""
    user = User.query.get_or_404(user_id)
    
    data = serialize_user(user)
    
    # Stats
    data['stats'] = {
        'followers': UserFollow.query.filter_by(following_id=user_id).count(),
        'following': UserFollow.query.filter_by(follower_id=user_id).count(),
        'posts': Post.query.filter_by(user_id=user_id, is_anonymous=False).count()
    }
    
    # Check if following
    if g.current_user:
        data['is_following'] = UserFollow.query.filter_by(
            follower_id=g.current_user.id,
            following_id=user_id
        ).first() is not None
    
    return jsonify(data)


@api_bp.route('/users/<int:user_id>/posts', methods=['GET'])
@optional_token
def get_user_posts(user_id):
    """Get user's public posts"""
    page = request.args.get('page', 1, type=int)
    
    query = Post.query.filter_by(user_id=user_id, is_anonymous=False)\
        .order_by(Post.created_at.desc())
    result = paginate(query, page)
    
    return jsonify({
        'posts': [serialize_post(p, g.current_user) for p in result['items']],
        'meta': result['meta']
    })


@api_bp.route('/users/<int:user_id>/follow', methods=['POST'])
@token_required
def follow_user(user_id):
    """Follow/unfollow a user"""
    if user_id == g.current_user.id:
        return jsonify({'error': 'Cannot follow yourself'}), 400
    
    user = User.query.get_or_404(user_id)
    
    existing = UserFollow.query.filter_by(
        follower_id=g.current_user.id,
        following_id=user_id
    ).first()
    
    if existing:
        db.session.delete(existing)
        is_following = False
    else:
        follow = UserFollow(follower_id=g.current_user.id, following_id=user_id)
        db.session.add(follow)
        is_following = True
        
        # Send notification
        from routes.notifications import notify_follow
        notify_follow(user_id, g.current_user)
    
    db.session.commit()
    
    return jsonify({
        'is_following': is_following,
        'follower_count': UserFollow.query.filter_by(following_id=user_id).count()
    })


# =============================================================================
# NOTIFICATION ENDPOINTS
# =============================================================================

@api_bp.route('/notifications', methods=['GET'])
@token_required
def get_notifications():
    """Get user notifications"""
    page = request.args.get('page', 1, type=int)
    unread_only = request.args.get('unread_only', 'false').lower() == 'true'
    
    query = Notification.query.filter_by(user_id=g.current_user.id)
    
    if unread_only:
        query = query.filter_by(is_read=False)
    
    query = query.order_by(Notification.created_at.desc())
    result = paginate(query, page)
    
    return jsonify({
        'notifications': [serialize_notification(n) for n in result['items']],
        'meta': result['meta'],
        'unread_count': Notification.query.filter_by(
            user_id=g.current_user.id,
            is_read=False
        ).count()
    })


@api_bp.route('/notifications/unread-count', methods=['GET'])
@token_required
def get_unread_count():
    """Get unread notification count"""
    count = Notification.query.filter_by(
        user_id=g.current_user.id,
        is_read=False
    ).count()
    
    return jsonify({'count': count})


@api_bp.route('/notifications/<int:notification_id>/read', methods=['POST'])
@token_required
def mark_notification_read(notification_id):
    """Mark notification as read"""
    notification = Notification.query.filter_by(
        id=notification_id,
        user_id=g.current_user.id
    ).first_or_404()
    
    notification.is_read = True
    notification.read_at = datetime.utcnow()
    db.session.commit()
    
    return jsonify({'success': True})


@api_bp.route('/notifications/read-all', methods=['POST'])
@token_required
def mark_all_read():
    """Mark all notifications as read"""
    Notification.query.filter_by(
        user_id=g.current_user.id,
        is_read=False
    ).update({'is_read': True, 'read_at': datetime.utcnow()})
    
    db.session.commit()
    
    return jsonify({'success': True})


# =============================================================================
# PUSH NOTIFICATION ENDPOINTS
# =============================================================================

@api_bp.route('/push/register', methods=['POST'])
@token_required
def register_push_token():
    """Register push notification token (FCM/APNs)"""
    data = request.get_json()
    
    token = data.get('token')
    platform = data.get('platform')  # 'ios', 'android'
    device_id = data.get('device_id')
    
    if not token or not platform:
        return jsonify({'error': 'Token and platform required'}), 400
    
    # Store as PushSubscription with endpoint as token
    existing = PushSubscription.query.filter_by(
        user_id=g.current_user.id,
        endpoint=token
    ).first()
    
    if existing:
        existing.is_active = True
        existing.last_used = datetime.utcnow()
    else:
        sub = PushSubscription(
            user_id=g.current_user.id,
            endpoint=token,
            device_name=f"{platform.upper()} Device",
            user_agent=device_id or ''
        )
        db.session.add(sub)
    
    db.session.commit()
    
    return jsonify({'success': True})


@api_bp.route('/push/unregister', methods=['POST'])
@token_required
def unregister_push_token():
    """Unregister push token"""
    data = request.get_json()
    token = data.get('token')
    
    if token:
        PushSubscription.query.filter_by(
            user_id=g.current_user.id,
            endpoint=token
        ).delete()
        db.session.commit()
    
    return jsonify({'success': True})


# =============================================================================
# SEARCH ENDPOINTS
# =============================================================================

@api_bp.route('/search', methods=['GET'])
@optional_token
def search():
    """Search posts, users, hashtags"""
    query = request.args.get('q', '').strip()
    search_type = request.args.get('type', 'all')  # all, posts, users, hashtags
    page = request.args.get('page', 1, type=int)
    
    if not query:
        return jsonify({'error': 'Query required'}), 400
    
    results = {}
    
    if search_type in ['all', 'posts']:
        posts = Post.query.filter(Post.content.ilike(f'%{query}%'))\
            .order_by(Post.created_at.desc()).limit(20).all()
        results['posts'] = [serialize_post(p, g.current_user) for p in posts]
    
    if search_type in ['all', 'users']:
        users = User.query.filter(
            db.or_(
                User.first_name.ilike(f'%{query}%'),
                User.last_name.ilike(f'%{query}%'),
                User.email.ilike(f'%{query}%')
            )
        ).limit(20).all()
        results['users'] = [serialize_user(u) for u in users]
    
    if search_type in ['all', 'hashtags']:
        hashtags = Hashtag.query.filter(Hashtag.name.ilike(f'%{query}%'))\
            .order_by(Hashtag.post_count.desc()).limit(20).all()
        results['hashtags'] = [{
            'name': h.name,
            'post_count': h.post_count
        } for h in hashtags]
    
    return jsonify(results)


# =============================================================================
# BOOKMARKS ENDPOINT
# =============================================================================

@api_bp.route('/bookmarks', methods=['GET'])
@token_required
def get_bookmarks():
    """Get user's bookmarked posts"""
    page = request.args.get('page', 1, type=int)
    
    query = Post.query.join(Bookmark).filter(
        Bookmark.user_id == g.current_user.id
    ).order_by(Bookmark.created_at.desc())
    
    result = paginate(query, page)
    
    return jsonify({
        'posts': [serialize_post(p, g.current_user) for p in result['items']],
        'meta': result['meta']
    })


# =============================================================================
# AMA ENDPOINTS
# =============================================================================

@api_bp.route('/amas', methods=['GET'])
@optional_token
def get_amas():
    """Get upcoming and past AMAs"""
    upcoming = ExpertAMA.query.filter(
        ExpertAMA.scheduled_for > datetime.utcnow()
    ).order_by(ExpertAMA.scheduled_for.asc()).limit(10).all()
    
    past = ExpertAMA.query.filter(
        ExpertAMA.scheduled_for <= datetime.utcnow()
    ).order_by(ExpertAMA.scheduled_for.desc()).limit(10).all()
    
    def serialize_ama(ama):
        return {
            'id': ama.id,
            'title': ama.title,
            'expert_name': ama.expert_name,
            'expert_title': ama.expert_title,
            'description': ama.description,
            'scheduled_for': ama.scheduled_for.isoformat(),
            'duration_minutes': ama.duration_minutes,
            'is_premium_only': ama.is_premium_only,
            'status': ama.status.value,
            'participant_count': ama.participant_count
        }
    
    return jsonify({
        'upcoming': [serialize_ama(a) for a in upcoming],
        'past': [serialize_ama(a) for a in past]
    })


# =============================================================================
# DEALS ENDPOINTS
# =============================================================================

@api_bp.route('/deals', methods=['GET'])
@token_required
def get_deals():
    """Get investment deals (premium feature)"""
    if not g.current_user.is_premium:
        return jsonify({'error': 'Premium subscription required'}), 403
    
    deals = InvestmentDeal.query.filter_by(status='active')\
        .order_by(InvestmentDeal.created_at.desc()).all()
    
    return jsonify({
        'deals': [{
            'id': d.id,
            'title': d.title,
            'description': d.description[:200] + '...' if len(d.description) > 200 else d.description,
            'deal_type': d.deal_type,
            'minimum_investment': d.minimum_investment,
            'projected_return': d.projected_return,
            'investment_term': d.investment_term,
            'location': d.location,
            'is_featured': d.is_featured
        } for d in deals]
    })


# =============================================================================
# ERROR HANDLERS
# =============================================================================

@api_bp.errorhandler(404)
def not_found(e):
    return jsonify({'error': 'Resource not found'}), 404


@api_bp.errorhandler(500)
def server_error(e):
    return jsonify({'error': 'Internal server error'}), 500
